# Implementation Guide gPAS - v2026.2.0

 ![](assets/images/Design-Logo-THS-deutsch-271-padding.png) 

 
 2026.2.0 - ci-build  

* [**Table of Contents**](toc.md)
* **Implementation Guide gPAS**

## Implementation Guide gPAS

| | |
| :--- | :--- |
| *Official URL*:https://ths-greifswald.de/fhir/gpas/ImplementationGuide/ths-greifswald.ttp-fhir-gw.gpas | *Version*:2026.2.0 |
| Active as of 2026-10-06 | *Computable Name*:IGTTPFHIRGatewaygPAS |

# FHIR-Support für Pseudonymmanagement

Stand 06.10.2026

Die Softwarelösungen E-PIX, gPAS und gICS werden in zahlreichen Forschungseinrichtungen und Projekten für die Realisierung von Treuhandstellen-Services (THS) eingesetzt. Um die Verwendung dieser Lösungen in FHIR-basierten Infrastrukturen zu unterstützen, werden ausgewählte THS-Funktionalitäten in durch FHIR-basierte Operations, Profile, Erweiterungen und Terminologien realisiert.

Diese werden in entsprechenden [Implementierungsleitfäden](https://www.ths-greifswald.de/fhir) themenspezifisch beschrieben und zahlreiche Details erläutert.

Der vorliegende **Implementation Guide gPAS** setzt den Fokus auf Operations, CodeSysteme und ValueSets von [gPAS].

### Endpunkt

Der FHIR-Endpunkt (`base`) für das Pseudonymmanagement ist

**`http[s]://\<host\>:\<port\>/ttp-fhir/fhir/gpas`**

 ![](assets/images/fhirgw-gpas.png) 

### Package

Das automatisch erzeugte Package (TGZ) steht als Download zur Verfügung unter: [Link](package.tgz).

### Implementierung

Peter Penndorf, Martin Bialke, Christoper Hampf, Frank Michael Moser

### Autoren

Martin Bialke, Stefan Lang

### Kontakt

kontakt-ths (at) med.uni-greifswald.de

