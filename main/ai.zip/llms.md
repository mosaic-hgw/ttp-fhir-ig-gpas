# ths-greifswald.ttp-fhir-gw.gpas#2025.2.0: null

## Pages

* [Implementation Guide gPAS](index.md)
* [Artifacts Summary](artifacts.md)
* [Allgemein](Allgemein.md)

## Resources

### ImplementationGuides

* [IGTTPFHIRGatewaygPAS](index.md)

### OperationDefinitions

* [anonymizeOriginals](OperationDefinition-AnonymizeOriginals.md)
* [dePseudonymize](OperationDefinition-DePseudonymize.md)
* [deletePseudonyms](OperationDefinition-DeletePseudonyms.md)
* [insertValuePseudonymPairs](OperationDefinition-InsertValuePseudonymPairs.md)
* [pseudonymize](OperationDefinition-Pseudonymize.md)
* [pseudonymizeAllowCreate](OperationDefinition-PseudonymizeAllowCreate.md)
* [pseudonymize-secondary](OperationDefinition-PseudonymizeSecondary.md)

### Examples

* [Parameters-AnonymizeOriginals-request-example-1 (Parameters)](Parameters-Parameters-AnonymizeOriginals-request-example-1.md)
* [Parameters-AnonymizeOriginals-response-example-1 (Parameters)](Parameters-Parameters-AnonymizeOriginals-response-example-1.md)
* [Parameters-DePseudonymize-request-example-1 (Parameters)](Parameters-Parameters-DePseudonymize-request-example-1.md)
* [Parameters-DePseudonymize-response-example-1 (Parameters)](Parameters-Parameters-DePseudonymize-response-example-1.md)
* [Parameters-DePseudonymize-response-example-2 (Parameters)](Parameters-Parameters-DePseudonymize-response-example-2.md)
* [Parameters-DeletePseudonyms-request-example-1 (Parameters)](Parameters-Parameters-DeletePseudonyms-request-example-1.md)
* [Parameters-DeletePseudonyms-response-example-1 (Parameters)](Parameters-Parameters-DeletePseudonyms-response-example-1.md)
* [Parameters-InsertValuePseudonymPairs-request-example-1 (Parameters)](Parameters-Parameters-InsertValuePseudonymPairs-request-example-1.md)
* [Parameters-InsertValuePseudonymPairs-response-example-1 (Parameters)](Parameters-Parameters-InsertValuePseudonymPairs-response-example-1.md)
* [Parameters-InsertValuePseudonymPairs-response-example-2 (Parameters)](Parameters-Parameters-InsertValuePseudonymPairs-response-example-2.md)
* [Parameters-Pseudonymize-request-example-1 (Parameters)](Parameters-Parameters-Pseudonymize-request-example-1.md)
* [Parameters-Pseudonymize-response-example-1 (Parameters)](Parameters-Parameters-Pseudonymize-response-example-1.md)
* [Parameters-Pseudonymize-response-example-2 (Parameters)](Parameters-Parameters-Pseudonymize-response-example-2.md)
* [Parameters-PseudonymizeAllowCreate-request-example-1 (Parameters)](Parameters-Parameters-PseudonymizeAllowCreate-request-example-1.md)
* [Parameters-PseudonymizeAllowCreate-response-example-1 (Parameters)](Parameters-Parameters-PseudonymizeAllowCreate-response-example-1.md)
* [Parameters-PseudonymizeSecondary-request-example-1 (Parameters)](Parameters-Parameters-PseudonymizeSecondary-request-example-1.md)
* [Parameters-PseudonymizeSecondary-response-example-1 (Parameters)](Parameters-Parameters-PseudonymizeSecondary-response-example-1.md)
* [Parameters-PseudonymizeSecondary-response-example-2 (Parameters)](Parameters-Parameters-PseudonymizeSecondary-response-example-2.md)
