# Kontext und Konzept - v2025.1.0

