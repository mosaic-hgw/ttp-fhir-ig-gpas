# ths-greifswald.ttp-fhir-gw.gpas#2025.2.0: null

## Pages

* [Implementation Guide gPAS](index.md)
* [Allgemein](Allgemein.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [BloomfilterType](CodeSystem-BloomfilterTypeCS.md)
* [ConsentComponentType](CodeSystem-ConsentComponentTypeCS.md)
* [ConsentPolicyAction](CodeSystem-ConsentPolicyActionCS.md)
* [ConsentPolicyActor](CodeSystem-ConsentPolicyActorCS.md)
* [ConsentPolicyClass](CodeSystem-ConsentPolicyClassCS.md)
* [ConsentPolicyPurpose](CodeSystem-ConsentPolicyPurposeCS.md)
* [ConsentStatus](CodeSystem-ConsentStatusCS.md)
* [DesignationUse](CodeSystem-DesignationUseCS.md)
* [IdMatchingType](CodeSystem-IdMatchingTypeCS.md)
* [IdatElements](CodeSystem-IdatElementsCS.md)
* [MatchStatus](CodeSystem-MatchStatusCS.md)
* [Policy](CodeSystem-PolicyCS.md)
* [SaveAction](CodeSystem-SaveActionCS.md)

### ValueSets

* [BloomfilterType](ValueSet-BloomfilterTypeVS.md)
* [ConsentComponentType](ValueSet-ConsentComponentTypeVS.md)
* [ConsentPolicyAction](ValueSet-ConsentPolicyActionVS.md)
* [ConsentPolicyActor](ValueSet-ConsentPolicyActorVS.md)
* [ConsentPolicyClass](ValueSet-ConsentPolicyClassVS.md)
* [ConsentPolicyPurpose](ValueSet-ConsentPolicyPurposeVS.md)
* [ConsentStatusConsentFullValues](ValueSet-ConsentStatusConsentFullValuesVS.md)
* [ConsentStatusConsentOptOutFullValues](ValueSet-ConsentStatusConsentOptOutFullValuesVS.md)
* [ConsentStatusConsentOptOutShortValues](ValueSet-ConsentStatusConsentOptOutShortValuesVS.md)
* [ConsentStatusConsentShortValues](ValueSet-ConsentStatusConsentShortValuesVS.md)
* [ConsentStatusObjectionFullValues](ValueSet-ConsentStatusObjectionFullValuesVS.md)
* [ConsentStatusObjectionShortValues](ValueSet-ConsentStatusObjectionShortValuesVS.md)
* [ConsentStatusRefusalFullValues](ValueSet-ConsentStatusRefusalFullValuesVS.md)
* [ConsentStatusRefusalShortValues](ValueSet-ConsentStatusRefusalShortValuesVS.md)
* [ConsentStatus](ValueSet-ConsentStatusVS.md)
* [ConsentStatusWithdrawalFullValues](ValueSet-ConsentStatusWithdrawalFullValuesVS.md)
* [ConsentStatusWithdrawalShortValues](ValueSet-ConsentStatusWithdrawalShortValuesVS.md)
* [IdMatchingType](ValueSet-IdMatchingTypeVS.md)
* [IdatElements](ValueSet-IdatElementsVS.md)
* [MatchStatus](ValueSet-MatchStatusVS.md)
* [PolicyStatus](ValueSet-PolicyStatusVS.md)
* [Policy](ValueSet-PolicyVS.md)
* [SaveAction](ValueSet-SaveActionVS.md)

### ImplementationGuides

* [IGTTPFHIRGatewaygPAS](index.md)

### OperationDefinitions

* [anonymizeOriginals](OperationDefinition-AnonymizeOriginals.md)
* [dePseudonymize](OperationDefinition-DePseudonymize.md)
* [deletePseudonyms](OperationDefinition-DeletePseudonyms.md)
* [insertValuePseudonymPairs](OperationDefinition-InsertValuePseudonymPairs.md)
* [pseudonymize](OperationDefinition-Pseudonymize.md)
* [pseudonymizeAllowCreate](OperationDefinition-PseudonymizeAllowCreate.md)
* [pseudonymize-secondary](OperationDefinition-PseudonymizeSecondary.md)

### Examples

* [Parameters-AnonymizeOriginals-request-example-1 (Parameters)](Parameters-Parameters-AnonymizeOriginals-request-example-1.md)
* [Parameters-AnonymizeOriginals-response-example-1 (Parameters)](Parameters-Parameters-AnonymizeOriginals-response-example-1.md)
* [Parameters-DePseudonymize-request-example-1 (Parameters)](Parameters-Parameters-DePseudonymize-request-example-1.md)
* [Parameters-DePseudonymize-response-example-1 (Parameters)](Parameters-Parameters-DePseudonymize-response-example-1.md)
* [Parameters-DePseudonymize-response-example-2 (Parameters)](Parameters-Parameters-DePseudonymize-response-example-2.md)
* [Parameters-DeletePseudonyms-request-example-1 (Parameters)](Parameters-Parameters-DeletePseudonyms-request-example-1.md)
* [Parameters-DeletePseudonyms-response-example-1 (Parameters)](Parameters-Parameters-DeletePseudonyms-response-example-1.md)
* [Parameters-InsertValuePseudonymPairs-request-example-1 (Parameters)](Parameters-Parameters-InsertValuePseudonymPairs-request-example-1.md)
* [Parameters-InsertValuePseudonymPairs-response-example-1 (Parameters)](Parameters-Parameters-InsertValuePseudonymPairs-response-example-1.md)
* [Parameters-InsertValuePseudonymPairs-response-example-2 (Parameters)](Parameters-Parameters-InsertValuePseudonymPairs-response-example-2.md)
* [Parameters-Pseudonymize-request-example-1 (Parameters)](Parameters-Parameters-Pseudonymize-request-example-1.md)
* [Parameters-Pseudonymize-response-example-1 (Parameters)](Parameters-Parameters-Pseudonymize-response-example-1.md)
* [Parameters-Pseudonymize-response-example-2 (Parameters)](Parameters-Parameters-Pseudonymize-response-example-2.md)
* [Parameters-PseudonymizeAllowCreate-request-example-1 (Parameters)](Parameters-Parameters-PseudonymizeAllowCreate-request-example-1.md)
* [Parameters-PseudonymizeAllowCreate-response-example-1 (Parameters)](Parameters-Parameters-PseudonymizeAllowCreate-response-example-1.md)
* [Parameters-PseudonymizeSecondary-request-example-1 (Parameters)](Parameters-Parameters-PseudonymizeSecondary-request-example-1.md)
* [Parameters-PseudonymizeSecondary-response-example-1 (Parameters)](Parameters-Parameters-PseudonymizeSecondary-response-example-1.md)
* [Parameters-PseudonymizeSecondary-response-example-2 (Parameters)](Parameters-Parameters-PseudonymizeSecondary-response-example-2.md)
