# Parameters-InsertValuePseudonymPairs-request-example-1 - v2025.1.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-InsertValuePseudonymPairs-request-example-1",
  "parameter" : [
    {
      "name" : "pseudonym",
      "part" : [
        {
          "name" : "target",
          "valueString" : "MIRACUM"
        },
        {
          "name" : "original",
          "valueString" : "1001000000022"
        },
        {
          "name" : "value",
          "valueString" : "mrcm_T0TYNV21"
        }
      ]
    }
  ]
}

```
