# pseudonymize - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "OperationDefinition",
  "id" : "Pseudonymize",
  "url" : "https://ths-greifswald.de/fhir/OperationDefinition/gpas/pseudonymize",
  "version" : "2025.2.0",
  "name" : "Pseudonymize",
  "title" : "pseudonymize",
  "status" : "active",
  "kind" : "operation",
  "date" : "2025-06-12",
  "publisher" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "contact" : [
    {
      "name" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.ths-greifswald.de/"
        }
      ]
    }
  ],
  "description" : "Abfrage je eines Pseudonym-Wertes für eine gegebene Liste von 1-n Originalwerten und eine spezifische Domäne.",
  "affectsState" : false,
  "code" : "pseudonymize",
  "comment" : "Abfrage je eines Pseudonym-Wertes für eine gegebene Liste von 1-n Originalwerten und eine spezifische Domäne.",
  "system" : true,
  "type" : false,
  "instance" : false,
  "parameter" : [
    {
      "name" : "target",
      "use" : "in",
      "min" : 1,
      "max" : "1",
      "documentation" : "Angabe der Domäne auf Basis derer für die angegebenen Originalwerte ein vorhandenens eindeutiges Pseudonym gesucht wird",
      "type" : "string",
      "searchType" : "string"
    },
    {
      "name" : "original",
      "use" : "in",
      "min" : 1,
      "max" : "*",
      "documentation" : "Angabe der Originalwerte für die in der angegebenen Domäne nach vorhandenen zugeordneten Pseudonymen gesucht wird",
      "type" : "string",
      "searchType" : "string"
    },
    {
      "name" : "pseudonym",
      "use" : "out",
      "min" : 0,
      "max" : "*",
      "documentation" : "Ermitteltes bzw. generiertes studien- und standort-spezifisches Pseudonym",
      "part" : [
        {
          "name" : "original",
          "use" : "out",
          "min" : 1,
          "max" : "1",
          "documentation" : "Original-Identifikator",
          "type" : "Identifier"
        },
        {
          "name" : "target",
          "use" : "out",
          "min" : 1,
          "max" : "1",
          "documentation" : "Target-Identifikator",
          "type" : "Identifier"
        },
        {
          "name" : "pseudonym",
          "use" : "out",
          "min" : 1,
          "max" : "1",
          "documentation" : "Pseudonym",
          "type" : "Identifier"
        }
      ]
    },
    {
      "name" : "error",
      "use" : "out",
      "min" : 0,
      "max" : "*",
      "documentation" : "Fehlerrückgabe bei Teil-Fehlern",
      "part" : [
        {
          "name" : "target",
          "use" : "out",
          "min" : 0,
          "max" : "1",
          "documentation" : "Target-Identifikator",
          "type" : "Identifier"
        },
        {
          "name" : "original",
          "use" : "out",
          "min" : 0,
          "max" : "1",
          "documentation" : "Original-Identifikator",
          "type" : "Identifier"
        },
        {
          "name" : "error-code",
          "use" : "out",
          "min" : 1,
          "max" : "1",
          "documentation" : "Fehlercode",
          "type" : "Coding"
        }
      ]
    }
  ]
}

```
