# Parameters-DePseudonymize-request-example-1 - v2025.1.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-DePseudonymize-request-example-1",
  "parameter" : [
    {
      "name" : "target",
      "valueString" : "MIRACUM"
    },
    {
      "name" : "pseudonym",
      "valueString" : "mrcm_T0TYNV21"
    },
    {
      "name" : "pseudonym",
      "valueString" : "mrcm_9GELEUVU"
    }
  ]
}

```
