# Implementation Guide gPAS - v2025.2.0

