# Parameters-PseudonymizeSecondary-request-example-1 - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-PseudonymizeSecondary-request-example-1",
  "parameter" : [
    {
      "name" : "original",
      "part" : [
        {
          "name" : "target",
          "valueString" : "Datensatz-Ebene"
        },
        {
          "name" : "value",
          "valueString" : "H3RAU56A8E"
        },
        {
          "name" : "count",
          "valueString" : "2"
        }
      ]
    }
  ]
}

```
