# Parameters-PseudonymizeAllowCreate-request-example-1 - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-PseudonymizeAllowCreate-request-example-1",
  "parameter" : [
    {
      "name" : "target",
      "valueString" : "MIRACUM"
    },
    {
      "name" : "original",
      "valueString" : "1001000000022"
    },
    {
      "name" : "original",
      "valueString" : "1001000000033"
    }
  ]
}

```
