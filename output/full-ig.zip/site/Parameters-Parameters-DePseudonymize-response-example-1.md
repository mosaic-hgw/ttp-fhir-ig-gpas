# Parameters-DePseudonymize-response-example-1 - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-DePseudonymize-response-example-1",
  "parameter" : [
    {
      "name" : "original",
      "part" : [
        {
          "name" : "target",
          "valueIdentifier" : {
            "system" : "https://ths-greifswald.de/gpas",
            "value" : "MIRACUM"
          }
        },
        {
          "name" : "original",
          "valueIdentifier" : {
            "system" : "https://ths-greifswald.de/gpas",
            "value" : "1001000000022"
          }
        },
        {
          "name" : "pseudonym",
          "valueIdentifier" : {
            "system" : "https://ths-greifswald.de/gpas",
            "value" : "mrcm_T0TYNV21"
          }
        }
      ]
    },
    {
      "name" : "original",
      "part" : [
        {
          "name" : "target",
          "valueIdentifier" : {
            "system" : "https://ths-greifswald.de/gpas",
            "value" : "MIRACUM"
          }
        },
        {
          "name" : "original",
          "valueIdentifier" : {
            "system" : "https://ths-greifswald.de/gpas",
            "value" : "1001000000033"
          }
        },
        {
          "name" : "pseudonym",
          "valueIdentifier" : {
            "system" : "https://ths-greifswald.de/gpas",
            "value" : "mrcm_9GELEUVU"
          }
        }
      ]
    }
  ]
}

```
